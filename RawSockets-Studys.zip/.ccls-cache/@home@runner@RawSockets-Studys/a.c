#include <stdio.h>


int main(){
    int numeros[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int aux;

    int i, j;

    for (i = 0, j = 9; i < j; i++, j--) {
         aux = numeros[i];
         numeros[i] = numeros[j];
         numeros[j] = aux;
    }

    for (i = 0; i < 10; i++) {
        printf("%d\n", numeros[i]);
    }
  
}

