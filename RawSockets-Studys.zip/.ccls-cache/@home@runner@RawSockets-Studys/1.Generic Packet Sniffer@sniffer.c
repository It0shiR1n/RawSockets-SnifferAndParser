// REMEBER TO PUT YOUR NIC IN TO A PROMISCUOUS MODE

#include <stdio.h>           // input e output 
#include <stdlib.h>          // Memory management
#include <sys/socket.h>      // socket
#include <features.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <errno.h> 
#include <sys/ioctl.h>
#include <net/if.h>



int bindRawSocketToIface(char *device, int sockfd, int protocol){
    struct sockaddr_ll iface;
    struct ifreq ifaceRequisition;

    bzero(&iface, sizeof(iface));
    bzero(&ifaceRequisition, sizeof(ifaceRequisition));

    // https://youtu.be/5hxOgml4MRY?list=PL9ueu6QbfMC3SYOBOkDHed09gnsGlhfVl (2:41)
    strncpy((char *)ifaceRequisition.ifr_name, device, IFNAMSIZ);

    if((ioctl(sockfd, SIOCGIFINDEX, &ifaceRequisition)) == -1 ){
        printf("Error to get the interface index! \n");
        exit(-1);
        
    }

    return 0;
    
}


void printHexDump(unsigned char *packet, int len){
    
    unsigned char *p = packet;

    printf("");    
    while(len--){
        printf("%.2x", *p);
        p++;
        
    }
    
}


int main(){ 
    int sockfd;                                             // Socket descriptor
    unsigned char packet_buffer[2048];                      // Buffer to receive packet

    int len; 
    int packet_to_sniff;
    struct sockaddr_ll packet_info;                         // Informations of the packets provided by the kernel
    unsigned int packet_info_size = sizeof(packet_info_size);

    
    // Creating the Raw Socket
    sockfd = socket(PF_PACKET, SOCK_RAW, htons("NUMBER OF THE PROTOCOL TO SNIFFER"));

    if(sockfd == -1){
        printf("Error in socket creation");
        exit(-1);
        
    }

    bindRawSocketToIface("eth0", sockfd, ETH_P_IP);

    packet_to_sniff = 2;

    while(packet_to_sniff--){
        if((len = recvfrom(sockfd, packet_buffer, 2048, 0, (struct sockaddr *)&packet_info, &packet_info_size)) == -1 ) {
            printf("Error in recvfrom");
            exit(-1);
            
        }else {
            printHexDump(packet_buffer, len);
            
        }
        
    }
    

    // how much packets do you want sniff?
    
}